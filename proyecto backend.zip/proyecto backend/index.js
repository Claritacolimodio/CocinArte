const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json()); // Asegúrate de que el cuerpo de las solicitudes se pueda analizar como JSON

// Configuración de multer para almacenar las imágenes
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'imagenes'); // Carpeta donde se guardarán las imágenes
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); // Guarda el archivo con su nombre original
  }
});

const upload = multer({ storage: storage });

// Crear una conexión a la base de datos MySQL
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  port: '3306',
  password: '221522',
  database: 'cocinarte'
});

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos: ', err);
    return;
  }
  console.log('Conectado a la base de datos MySQL');
});

// Ruta para verificar la conexión
app.get('/', (req, res) => {
  connection.query('SELECT 1 + 1 AS solution', (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta: ', err);
      res.status(500).send('Error en el servidor');
      return;
    }
    res.send(`La solución es: ${results[0].solution}`);
  });
});



// Ruta para iniciar sesión
app.post('/login', (req, res) => {
  const { correo_electronico, contrasena } = req.body;
  const query = 'SELECT * FROM Usuarios WHERE Correo_electronico = ? AND Contrasena = ?';

  connection.query(query, [correo_electronico, contrasena], (err, results) => {
    if (err) {
      console.error('Error al intentar iniciar sesión: ', err);
      return res.status(500).send('Error en el servidor');
    }

    if (results.length > 0) {
      // If the user is found, send success response with user data
      res.status(200).json({ success: true, data: results[0] });
    } else {
      // If no user found, send failure response
      res.status(401).json({ success: false, message: 'Correo o contraseña incorrectos' });
    }
  });
});

// Ruta para obtener todas las recetas
app.get('/recetas', (req, res) => {
  connection.query('SELECT * FROM recetas', (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta: ', err);
      res.status(500).send('Error en el servidor');
      return;
    }

    if (results.length > 0) {
      // Envía todas las recetas
      res.json(results);
    } else {
      res.status(404).send('No se encontraron recetas');
    }
  });
});

// Ruta para obtener una receta por ID
app.get('/recetas/:id', (req, res) => {
  const recetaId = req.params.id;
  const query = 'SELECT * FROM recetas WHERE ID = ?';
  
  connection.query(query, [recetaId], (err, results) => {
    if (err) {
      console.error('Error al obtener la receta:', err);
      res.status(500).send('Error en el servidor');
      return;
    }
    if (results.length > 0) {
      res.json(results[0]);
    } else {
      res.status(404).send('Receta no encontrada');
    }
  });
});

// Ruta para buscar recetas
app.get('/buscar-recetas', (req, res) => {
  const { titulo } = req.query; // Obtener el título de la consulta
  const query = 'SELECT * FROM recetas WHERE Titulo LIKE ?'; // Cambiar la consulta para filtrar
  connection.query(query, [`%${titulo}%`], (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta: ', err);
      res.status(500).send('Error en el servidor');
      return;
    }
    if (results.length > 0) {
      res.json(results);
    } else {
      res.status(404).send('No se encontraron recetas');
    }
  });
});

// Ruta para obtener todos los ingredientes
app.get('/ingredientes', (req, res) => {
  connection.query('SELECT * FROM Ingredientes', (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta: ', err);
      res.status(500).send('Error en el servidor');
      return;
    }

    if (results.length > 0) {
      res.json(results);
    } else {
      res.status(404).send('No se encontraron ingredientes');
    }
  });
});


// Ruta para subir una imagen
app.post('/subir-imagen', upload.single('imagen'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No se ha subido ninguna imagen.' });
  }
  res.status(200).json({ message: 'Imagen subida exitosamente', file: req.file });
});

// Ruta para registro
app.post('/registro', (req, res) => {
  const { nombre, apellido, correo_electronico, contrasena } = req.body;
  const query = 'INSERT INTO Usuarios (Nombre, Apellido, Correo_electronico, Contrasena) VALUES (?, ?, ?, ?)';

  connection.query(query, [nombre, apellido, correo_electronico, contrasena], (err, result) => {
    if (err) {
      console.error('Error al registrar el usuario: ', err);
      return res.status(500).send('Error en el servidor');
    }
    res.status(201).json({ id: result.insertId, nombre, apellido, correo_electronico });
  });
});

// Ruta para agregar un ítem (POST /items)
app.post('/ingredientes', (req, res) => {
  const newItem = req.body; // Obtener el nuevo ítem desde el cuerpo de la solicitud
  const query = 'INSERT INTO ingredientes (nombre) VALUES (?)'; 
  connection.query(query, [newItem.nombre], (err, result) => {
    if (err) {
      console.error('Error al agregar un ítem: ', err);
      res.status(500).send('Error en el servidor');
      return;
    }
    res.status(201).json({ id: result.insertId, ...newItem }); // Responder con el nuevo ítem agregado
  });
});



// Ruta para publicar una receta
app.post('/publicar-receta', upload.single('imagen'), (req, res) => {
  const { titulo, descripcion, instrucciones, id_usuario, ingredientes } = req.body;
  const imagen = req.file ? req.file.filename : null; // Verifica si hay un archivo subido

  // Validaciones básicas
  if (!titulo || !descripcion || !instrucciones || !id_usuario || !ingredientes) {
      return res.status(400).json({ message: 'Faltan campos requeridos' });
  }

  // Inserta la receta en la tabla Recetas
  const queryReceta = 'INSERT INTO Recetas (Titulo, Descripcion, Instrucciones, Fecha_publicacion, ID_usuario, Imagen) VALUES (?, ?, ?, NOW(), ?, ?)';
  
  connection.query(queryReceta, [titulo, descripcion, instrucciones, id_usuario, imagen], (err, result) => {
      if (err) {
          console.error('Error al publicar la receta: ', err);
          return res.status(500).send('Error en el servidor');
      }

      const recetaId = result.insertId; // ID de la receta recién insertada
      
      // Inserta los ingredientes en la tabla Receta_Ingredientes
      const ingredientesArray = JSON.parse(ingredientes); // Espera que los ingredientes vengan en formato JSON
      const insertIngredientes = ingredientesArray.map(ing => [recetaId, ing.id, ing.cantidad]);

      const queryIngredientes = 'INSERT INTO Receta_Ingredientes (ID_receta, ID_ingrediente, Cantidad) VALUES ?';
      connection.query(queryIngredientes, [insertIngredientes], (err) => {
          if (err) {
              console.error('Error al insertar ingredientes: ', err);
              return res.status(500).send('Error en el servidor');
          }

          res.status(201).json({ message: 'Receta publicada exitosamente', recetaId });
      });
  });
});


app.listen(port, () => {
  console.log(`API ejecutándose en el puerto ${port}`);
});
